
package com.mvplivmo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class LoginService {

    @Autowired
    private SignUpRepo signUpRepo;

    public SignUp loginUser(String email, String password) {
        Optional<SignUp> user = signUpRepo.findById(email);
        
        // Check if user exists and if the password matches
        if (user.isPresent() && user.get().getPassword().equals(password)) {
            return user.get();
        } else {
            throw new IllegalStateException("Invalid email or password");
        }
    }
}
