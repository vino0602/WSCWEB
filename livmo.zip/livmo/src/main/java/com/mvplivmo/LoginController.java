package com.mvplivmo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/login")
@CrossOrigin(origins = "http://localhost:8081/")
public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping
    public ResponseEntity<?> loginUser(@RequestBody Login login) {
        try {
            SignUp loggedInUser = loginService.loginUser(login.getEmail(), login.getPassword());
            return ResponseEntity.ok(loggedInUser);  // Return user data or JWT token if needed
        } catch (IllegalStateException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error occurred during login.");
        }
    }
}

